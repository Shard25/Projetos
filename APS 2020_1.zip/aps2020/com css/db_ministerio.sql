-- phpMyAdmin SQL Dump
-- version 3.4.9
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tempo de Geração: 18/11/2020 às 03h02min
-- Versão do Servidor: 5.5.20
-- Versão do PHP: 5.3.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de Dados: `db_ministerio`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_digitais`
--

CREATE TABLE IF NOT EXISTS `tb_digitais` (
  `cd_digital` int(11) NOT NULL AUTO_INCREMENT,
  `img_digital` varchar(100) NOT NULL,
  PRIMARY KEY (`cd_digital`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Extraindo dados da tabela `tb_digitais`
--

INSERT INTO `tb_digitais` (`cd_digital`, `img_digital`) VALUES
(1, '<img src="digital1.png" width="100px" height ="100">'),
(2, '<img src="digital2.png" width="100px" height ="100">'),
(3, '<img src="digital3.png" width="100px" height ="100">'),
(4, '<img src="digital4.png" width="100px" height ="100">');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_funcionario`
--

CREATE TABLE IF NOT EXISTS `tb_funcionario` (
  `cd_codigo` int(11) NOT NULL AUTO_INCREMENT,
  `nm_funcionario` varchar(30) NOT NULL,
  `fp_digital` varchar(100) NOT NULL,
  `cd_nivel` char(1) NOT NULL,
  PRIMARY KEY (`cd_codigo`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Extraindo dados da tabela `tb_funcionario`
--

INSERT INTO `tb_funcionario` (`cd_codigo`, `nm_funcionario`, `fp_digital`, `cd_nivel`) VALUES
(1, 'Wesley Marcelo', 'e7332e90189758d0a099061505b2ebfb', '1'),
(2, 'Paulo Bernardinelli', 'c0a591760fac0c187d16bc86851e0a95', '2'),
(3, 'Maria Vitoria', 'd22705c186a611ef96ea777867b04db9', '3');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_informacoes`
--

CREATE TABLE IF NOT EXISTS `tb_informacoes` (
  `cd_codigo` int(11) NOT NULL AUTO_INCREMENT,
  `nm_proprietario` varchar(200) NOT NULL,
  `nm_propriedade` varchar(200) NOT NULL,
  `end_rua` varchar(200) NOT NULL,
  `end_numero` varchar(200) NOT NULL,
  `end_bairro` varchar(200) NOT NULL,
  `end_cidade` varchar(200) NOT NULL,
  `end_estado` varchar(200) NOT NULL,
  `nm_agrotoxico` varchar(200) DEFAULT NULL,
  `ds_agrotoxico` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`cd_codigo`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Extraindo dados da tabela `tb_informacoes`
--

INSERT INTO `tb_informacoes` (`cd_codigo`, `nm_proprietario`, `nm_propriedade`, `end_rua`, `end_numero`, `end_bairro`, `end_cidade`, `end_estado`, `nm_agrotoxico`, `ds_agrotoxico`) VALUES
(1, 'Adilson Junior', 'Alameda dos Anjos', 'Rua Jandir Cruzes de Ferraz', '254', 'Coronel', 'Itanhaém', 'São Paulo', 'Metrifonato,Carbendazim, Glifosato.', 'Contaminação do solo, dos lençois freaticos, rios e mares.'),
(2, 'Marcos Vinicius', 'Fazenda Pé de Alecrim', 'Estrada Coronel Joaquim Branco', '1538', 'Savoy', 'Itanhaém', 'São Paulo', 'Carbendazim, Glifosato.', 'Contaminação do solo, dos lençois freaticos, rios e mares.'),
(3, 'Jonatha Gomes', 'Chácara das Tamaras', 'Rua Campos Melo', '883', 'Vila Mathias', 'Santos', 'São Paulo', 'Glifosato, Abamectina.', 'Contaminação do solo, dos lençois freaticos, rios e mares.'),
(4, 'Luiz Fornaciari', 'Fazenda Bom D''ouro', 'Rodovia Cleide Faria Lima', '429', 'Bom Jesus', 'Mazagão', 'Amapá', 'Metrifonato, Carbofurano.', 'Contaminação do solo, dos lençois freaticos, rios e mares.'),
(5, 'Gerson Bueno', 'Fazenda Mares do Sul', 'Rua Oscar Pereira da Silva', '602', 'Guapura', 'Itanhaém', 'São Paulo', 'Carbendazim, Carbofurano.', 'Contaminação do solo, dos lençois freaticos, rios e mares.');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
