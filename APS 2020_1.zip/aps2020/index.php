<html>
	<head>
		<title>
			Ministerio do Meio Ambiente
		</title>
		
	</head>
	<body>
		<center>
			<form action="verificacao.php" method="post">
				</br>
				<label for="myfile"><h3>Selecione a digital: </h3></label>
				<input type="file" id="myfile" name="myfile">
				
					<br/>
						 <button type="submit" class="button button-block"/>Verificar</button> 
			</form>
		</center>
	</body>
</html>