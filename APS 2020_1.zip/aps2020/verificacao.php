<html>
	<head>
		<title>
			Ministerio do Meio Ambiente
		</title>
	</head>
	<body>
	<?php
	if(isset($_POST['myfile'])){
			$fingerprint = md5_file($_POST['myfile']);
			
			session_start ();
						$servidor = 'localhost';
						$user = 'root';
						$senha = 'usbw';
						$banco = 'db_ministerio';
						$mysqli = new mysqli($servidor, $user, $senha, $banco);
									
						if(mysqli_connect_errno()){
							trigger_error(mysqli_connect_error());
						}
						
			$digital1 = $mysqli->query("SELECT fp_digital FROM tb_funcionario where cd_nivel=3");
		while ($obj = mysqli_fetch_object($digital1)){
		
			if( $fingerprint == $obj->fp_digital){
					
				$query = $mysqli->query("SELECT nm_proprietario, nm_propriedade, end_rua, end_numero, end_bairro, end_cidade, end_estado, nm_agrotoxico, ds_agrotoxico FROM tb_informacoes"); 
							
					echo '<table border="1">'.
							'<tr>'.
								'<th>Propriet�rio</th>'.
								'<th>Propriedade</th>'.
								'<th>Endere�o</th>'.
								'<th>Bairro</th>'.
								'<th>Cidade</th>'.
								'<th>Estado</th>'.
								'<th>Agrot�xicos</th>'.
								'<th>Descri��o dos danos</th>'.
							'</tr>';
					while ($obj = mysqli_fetch_object($query)){
							
						echo
							'<tr>'.
								'<td>'.$obj->nm_proprietario.'</td>'.
								'<td>'.$obj->nm_propriedade.'</td>'.
								'<td>'.$obj->end_rua.', '.$obj->end_numero.'</td>'.
								'<td>'.$obj->end_bairro.'</td>'.
								'<td>'.$obj->end_cidade.'</td>'.
								'<td>'.$obj->end_estado.'</td>'.
								'<td>'.$obj->nm_agrotoxico.'</td>'.
								'<td>'.$obj->ds_agrotoxico.'</td>'.
							'</tr>';
					}
					echo '</table>';
					exit;
			}
		}
		$digital2 = $mysqli->query("SELECT fp_digital FROM tb_funcionario where cd_nivel=2");
		while ($obj = mysqli_fetch_object($digital2)){
			if( $fingerprint == $obj->fp_digital){
						
				$query = $mysqli->query("SELECT nm_proprietario, nm_propriedade FROM tb_informacoes"); 
								
					echo '<table border="1">'.
							'<tr>'.
								'<th>Propriet�rio</th>'.
								'<th>Propriedade</th>'.
							'</tr>';
					while ($obj = mysqli_fetch_object($query)){
							
						echo
							'<tr>'.
								'<td>'.$obj->nm_proprietario.'</td>'.
								'<td>'.$obj->nm_propriedade.'</td>'.
							'</tr>';
					}
					echo '</table>';
					exit;
			}
		}
		
		$digital3 = $mysqli->query("SELECT fp_digital FROM tb_funcionario where cd_nivel=1");
		while ($obj = mysqli_fetch_object($digital3)){
			if( $fingerprint == $obj->fp_digital){
						
				$query = $mysqli->query("SELECT nm_propriedade FROM tb_informacoes"); 
				
					echo '<table border="1">'.
							'<tr>'.
								'<th>Propriedade</th>'.
							'</tr>';
					while ($obj = mysqli_fetch_object($query)){
							
						echo
							'<tr>'.
								'<td>'.$obj->nm_propriedade.'</td>'.
							'</tr>';
					}
					echo '</table>';
					exit;
			}
		}
		
			$digitalDesc = $mysqli->query("SELECT fp_digital FROM tb_funcionario");
		while ($obj = mysqli_fetch_object($digitalDesc)){
			if( $fingerprint <> $obj->fp_digital){
				
				echo "<script>
				alert('Sua digital n�o est� cadastrada, tente novamente!');";
				echo "javascript:history.go(-1);
				</script>";
				
				exit;
			}
		}
		
		
	}
	else{
	}
?>
</body>
</html>