package apsFinal;

import java.awt.event.KeyEvent;
import java.util.Observable;
import java.util.Observer;
import javax.swing.GroupLayout.Alignment;
import javax.swing.GroupLayout;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class JanelaChat2 extends javax.swing.JFrame implements Observer {

    private Conexao conexao;

    public JanelaChat2(Conexao conexao) {
        super("Chat Simples em Java by @pcollares");
        this.conexao = conexao;
        initComponents();
        conexao.addObserver(this);
        escreve("Chat iniciado com " + conexao.getIp() + ":" + conexao.getPorta());
        mensagemjTextArea.requestFocusInWindow();
    }

    private void envia() {
        if (!mensagemjTextArea.getText().isEmpty()) {
            conexao.envia(mensagemjTextArea.getText());
            escreve("Voc� disse: "+mensagemjTextArea.getText());
            mensagemjTextArea.setText("");
        }
    }

    private void escreve(String texto){
        chatjTextArea.append(texto+"\n");
         if (!chatjTextArea.getText().isEmpty() && !chatjTextArea.isFocusOwner()) {
                chatjTextArea.setCaretPosition(chatjTextArea.getText().length() - 1);
            }
        
    }
    
    @SuppressWarnings("unchecked")
    //                           
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jScrollPane2 = new javax.swing.JScrollPane();
        mensagemjTextArea = new javax.swing.JTextArea();
        enviarjButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        mensagemjTextArea.setColumns(20);
        mensagemjTextArea.setRows(5);
        mensagemjTextArea.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                mensagemjTextAreaKeyReleased(evt);
            }
        });
        jScrollPane2.setViewportView(mensagemjTextArea);

        enviarjButton.setText("Enviar");
        enviarjButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                enviarjButtonActionPerformed(evt);
            }
        });
        
        btnEmoji = new JButton();
        btnEmoji.setBackground(new Color(240, 240, 240));
        btnEmoji.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		
        		Emoji frame = new Emoji();
        		frame.setVisible(true);
        		
        	}
        });
        btnEmoji.setText("Emoji");
        chatjTextArea = new javax.swing.JTextArea();
        
                chatjTextArea.setEditable(false);
                chatjTextArea.setColumns(20);
                chatjTextArea.setRows(5);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        layout.setHorizontalGroup(
        	layout.createParallelGroup(Alignment.LEADING)
        		.addGroup(layout.createSequentialGroup()
        			.addComponent(jScrollPane1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
        			.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        			.addComponent(chatjTextArea, GroupLayout.PREFERRED_SIZE, 505, GroupLayout.PREFERRED_SIZE))
        		.addGroup(layout.createSequentialGroup()
        			.addComponent(jScrollPane2, GroupLayout.PREFERRED_SIZE, 386, GroupLayout.PREFERRED_SIZE)
        			.addPreferredGap(ComponentPlacement.RELATED)
        			.addGroup(layout.createParallelGroup(Alignment.LEADING)
        				.addComponent(enviarjButton, GroupLayout.DEFAULT_SIZE, 102, Short.MAX_VALUE)
        				.addComponent(btnEmoji, GroupLayout.DEFAULT_SIZE, 102, Short.MAX_VALUE))
        			.addContainerGap())
        );
        layout.setVerticalGroup(
        	layout.createParallelGroup(Alignment.LEADING)
        		.addGroup(layout.createSequentialGroup()
        			.addGroup(layout.createParallelGroup(Alignment.BASELINE)
        				.addComponent(jScrollPane1, GroupLayout.PREFERRED_SIZE, 349, GroupLayout.PREFERRED_SIZE)
        				.addComponent(chatjTextArea, GroupLayout.PREFERRED_SIZE, 347, GroupLayout.PREFERRED_SIZE))
        			.addPreferredGap(ComponentPlacement.RELATED)
        			.addGroup(layout.createParallelGroup(Alignment.TRAILING, false)
        				.addComponent(jScrollPane2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
        				.addGroup(layout.createSequentialGroup()
        					.addComponent(enviarjButton, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        					.addPreferredGap(ComponentPlacement.UNRELATED)
        					.addComponent(btnEmoji, GroupLayout.PREFERRED_SIZE, 43, GroupLayout.PREFERRED_SIZE)))
        			.addContainerGap(19, Short.MAX_VALUE))
        );
        getContentPane().setLayout(layout);

        pack();
    }//                         

    private void enviarjButtonActionPerformed(java.awt.event.ActionEvent evt) {                                              
        envia();
    }                                             

    private void mensagemjTextAreaKeyReleased(java.awt.event.KeyEvent evt) {                                              
         if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            envia();
        }
    }                                             

    // Variables declaration - do not modify                     
    private javax.swing.JTextArea chatjTextArea;
    private javax.swing.JButton enviarjButton;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea mensagemjTextArea;
    private JButton btnEmoji;
    // End of variables declaration                   

    @Override
    public void update(Observable o, Object arg) {
        escreve(conexao.getMensagem());
    }
}